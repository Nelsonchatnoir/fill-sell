var e=`---
title: "Comment calculer vos profits sur Vinted : le guide complet"
description: "Apprenez à calculer vos marges nettes sur Vinted en tenant compte de tous les frais — achat, emballage, livraison. Exemples concrets et formule simple."
date: "2026-06-15"
lang: "fr"
og_image: "/og-image.jpg"
---

Vendre sur Vinted semble simple : on achète un vêtement pas cher, on le revend plus cher. Mais sans calculer correctement votre marge, vous risquez de travailler pour rien — voire à perte.

Voici la méthode complète pour calculer vos profits réels sur Vinted.

## Les frais à prendre en compte

Contrairement à ce qu'on pourrait croire, vendre sur Vinted génère plusieurs types de coûts.

### 1. Le prix d'achat

C'est le montant payé pour l'article : vide-greniers, brocantes, lots de friperie, Vinted lui-même en achat-revente... Ce coût est la base de tout calcul de marge.

### 2. Les frais d'emballage

Sac plastique, boîte carton, ruban adhésif, papier bulle. En moyenne, comptez **0,30 € à 0,80 €** par article selon la taille. Négligés, ces frais grignotent silencieusement votre marge sur des dizaines d'articles.

### 3. Les frais de livraison

Sur Vinted, c'est l'acheteur qui paie les frais de livraison — c'est un vrai avantage. **Mais** si vous proposez la livraison offerte pour booster vos ventes, vous absorbez ce coût (2,65 € à 8 € selon le transporteur).

### 4. Les commissions

Vinted ne prélève **aucune commission sur le vendeur**. C'est la protection acheteur (payée par l'acheteur) qui couvre les frais de plateforme. Avantage décisif par rapport à eBay (13 %) ou Depop (10 %).

## La formule de calcul

\`\`\`
Profit = Prix de vente − Prix d'achat − Frais d'emballage − Livraison (si à votre charge)
\`\`\`

**Exemple concret :**

| | |
|---|---|
| Jean Levi's 501 acheté en vide-greniers | 8 € |
| Prix de vente sur Vinted | 32 € |
| Emballage | 0,50 € |
| Livraison (payée par l'acheteur) | 0 € |
| **Profit net** | **23,50 €** |
| **Marge** | **73 %** |

## Calculer votre ROI

Le ROI (retour sur investissement) vous indique combien vous multipliez chaque euro investi :

\`\`\`
ROI = (Profit ÷ Prix d'achat) × 100
\`\`\`

Pour notre jean : \`(23,50 ÷ 8) × 100 = **293 %**\`

Vous avez presque quadruplé votre mise.

## Le cas des lots

Quand vous achetez un lot de 20 vêtements à 60 €, le prix de revient unitaire est **3 €** — pas 60 €. Répartir le coût d'achat sur chaque article est indispensable pour connaître votre vraie marge article par article.

\`\`\`
Prix de revient unitaire = Coût total du lot ÷ Nombre d'articles
\`\`\`

Si vous vendez chaque pièce 12 € : \`Profit = 12 − 3 − 0,50 = 8,50 €\` soit **71 % de marge**.

## Les erreurs les plus courantes

**Oublier l'emballage.** Sur 100 articles à 0,50 € d'emballage = 50 € perdus sans s'en rendre compte.

**Ne pas amortir les lots.** Attribuer le coût total du lot à un seul article fausse complètement votre analyse.

**Ignorer le temps de stockage.** Un article qui reste 6 mois en stock occupe de l'espace et immobilise du capital.

**Compter les revenus bruts comme profits.** 500 € de chiffre d'affaires avec 400 € d'achats = 100 € de marge, pas 500 €.

## Automatiser ces calculs

Faire ces calculs à la main pour 50 articles par semaine devient vite épuisant — et les erreurs s'accumulent. FillSell automatise tout : vous dictez vos achats par commande vocale, et l'app calcule automatiquement votre marge, votre ROI et vos statistiques de vente en temps réel.

Et une fois la marge maîtrisée, le levier suivant est l'exposition : le même article proposé sur plusieurs plateformes se vend plus vite, au même prix. C'est ce que couvrent nos guides sur [la publication d'une annonce sur plusieurs plateformes en une seule fois](/blog/publier-annonce-plusieurs-plateformes) et [le cross-listing entre Vinted, Leboncoin, eBay et Beebs](/blog/cross-listing-vinted-leboncoin).
`,t=`---
title: "Cross-listing : vendre sur Vinted et Leboncoin en même temps"
description: "Publier le même article sur Vinted, Leboncoin, eBay et Beebs sans double vente et sans cadence de robot : ce qu'est vraiment le cross-listing, en quoi il diffère de la republication, et comment choisir un outil sans mauvaise surprise."
date: "2026-08-02"
lang: "fr"
og_image: "/og-image-fillsell.png"
faq: [{"q":"Quelle est la différence entre cross-listing et republication automatique ?","a":"Le cross-listing publie un article une seule fois, sur plusieurs plateformes à la fois : il élargit l'audience. La republication redépose une annonce sur un seul site pour la faire remonter dans les résultats : elle relance la visibilité d'un article qui n'est plus vu. Les deux se complètent, et FillSell fait les deux — la republication au rythme d'une vraie personne, avec un plafond que vous réglez et une coupure à tout moment. Ce qui expose un compte, c'est la cadence de robot, pas le geste."},{"q":"Vendre le même article sur plusieurs plateformes est-il autorisé ?","a":"Publier un même article sur Vinted, Leboncoin, eBay et Beebs relève de votre liberté de vendeur : chaque annonce est déposée normalement, via le formulaire du site. Ce qui expose un compte, ce sont les cadences de robot — une annonce recyclée toutes les heures, des échanges de favoris artificiels — pas le fait de vendre au même moment sur plusieurs sites."},{"q":"Comment éviter de vendre deux fois le même article ?","a":"C'est le vrai risque du cross-listing. Il faut que l'outil détecte la vente sur une plateforme et retire l'annonce des autres. FillSell détecte la vente et vous prévient : vous confirmez, et il retire les annonces des autres plateformes en un tap. Le retrait n'est jamais déclenché sans vous — une disparition d'annonce n'est pas toujours une vente."},{"q":"FillSell fonctionne-t-il ordinateur éteint ?","a":"Non, et nous préférons le dire clairement : les publications et retraits passent par l'extension Chrome, donc par votre navigateur, avec vos sessions. Ordinateur éteint, rien ne part — les annonces attendent en file et partent à la prochaine ouverture de Chrome."},{"q":"Sur combien de plateformes FillSell publie-t-il ?","a":"Quatre : Vinted, Leboncoin, eBay et Beebs. Vous choisissez lesquelles activer, article par article — de une à quatre."}]
---

« Cross-listing », « cross-posting », « multiposting » : trois mots pour la même idée — proposer le même article sur plusieurs sites de vente à la fois, au lieu de le laisser attendre sur un seul. C'est l'un des rares leviers de vente qui ne demande ni de baisser son prix, ni de refaire ses photos : l'article est le même, il est simplement visible par plus d'acheteurs.

Cet article explique ce qu'est le cross-listing, en quoi il diffère de la republication — les deux sont utiles, on les confond souvent —, le piège de la double vente, et ce qu'il faut vérifier avant de confier ses annonces à un outil.

![Un même article proposé sur plusieurs plateformes de seconde main à la fois](/og-image-fillsell.png)

## Le cross-listing, c'est quoi exactement ?

Le principe tient en une phrase : une annonce rédigée une fois, déposée sur plusieurs plateformes en même temps. Un jean publié sur Vinted touche les acheteurs de Vinted ; le même jean publié aussi sur Leboncoin, eBay et Beebs touche quatre publics qui ne se recoupent que très peu. L'article ne devient pas meilleur — il devient trouvable.

En pratique, presque personne ne le fait à la main, et pour une raison simple : chaque site a son formulaire, ses catégories, ses libellés d'état, ses champs obligatoires. Déposer proprement le même article sur quatre sites, c'est quatre saisies complètes. C'est ce travail-là que les outils de cross-listing automatisent — nous avons détaillé le déroulé complet côté FillSell dans [Publier ses annonces sur plusieurs plateformes en une seule fois](/blog/publier-annonce-plusieurs-plateformes).

## Cross-listing et republication : deux gestes différents

C'est la confusion la plus répandue, et elle mérite d'être dissipée avant toute chose : les deux se ressemblent de loin, mais ne résolvent pas le même problème.

**Le cross-listing publie une fois.** Une annonce par plateforme, déposée par le formulaire normal du site, comme vous l'auriez fait au clavier. Elle vit ensuite sa vie d'annonce ordinaire.

**La republication remet une annonce en haut.** Sur un seul site — presque toujours Vinted —, l'annonce est retirée puis redéposée pour repasser devant les acheteurs. C'est utile : passé trois semaines, une annonce Vinted n'est quasiment plus vue. Ce qui expose un compte, ce n'est pas le geste, c'est la cadence de robot — une annonce recyclée toutes les heures, jour et nuit, se repère.

FillSell fait les deux, et pose des garde-fous sur le second : republication **au rythme d'une vraie personne**, avec **un plafond que vous réglez** et **une coupure possible à tout moment**. Manuelle sur tous les plans, automatisable avec le plan Pro — jamais activée dans votre dos. À la publication comme à la republication, l'extension marque des délais variables et saisit les champs à un rythme de frappe naturel, puis vérifie que le site a bien confirmé la mise en ligne.

## Le vrai risque du cross-listing : la double vente

Multiplier les vitrines a une contrepartie arithmétique : si l'article part sur Leboncoin ce soir, l'annonce Vinted, elle, ne le sait pas. Un deuxième acheteur peut payer un article qui n'existe plus — et vous voilà à annuler une vente, rembourser, et encaisser l'avis négatif.

Un outil de cross-listing sérieux doit donc gérer la sortie autant que l'entrée. Chez FillSell, la détection est automatique, le retrait est à vous : quand un article est vendu quelque part, l'application vous prévient et vous retirez les autres annonces en un tap — l'extension exécute alors les suppressions site par site, par le même mécanisme que la publication. Vous pouvez aussi retirer une annonce d'un site précis, d'un clic sur son logo, sans toucher aux autres.

Pourquoi une confirmation plutôt qu'un retrait d'office ? Parce qu'une annonce qui disparaît n'est pas toujours une vente : elle peut avoir expiré, être passée en révision, ou avoir été retirée par vous. Supprimer trois annonces vivantes sur une fausse détection coûte plus cher que le tap qu'on vous demande.

Un point d'honnêteté ici aussi : ce retrait passe par votre navigateur, comme le reste. Une fois confirmé, il n'est pas instantané à la seconde près — l'extension traite les suppressions dans les minutes qui suivent, quand Chrome est ouvert. C'est le cas de tous les outils qui travaillent avec vos sessions ; ceux qui promettent l'instantané absolu passent par d'autres moyens, ce qui amène à la question suivante.

## Extension Chrome ou service distant : sachez ce que fait l'outil à votre place

Tous les outils de cross-listing doivent résoudre le même problème : les plateformes de seconde main n'offrent pas d'accès officiel pour déposer des annonces à votre place. Il n'existe que deux façons de contourner cette absence, et elles n'ont pas les mêmes implications.

**Travailler dans votre navigateur, avec vos sessions.** C'est le choix de FillSell, sous forme d'une extension Chrome. Vous restez connecté à Vinted, Leboncoin, eBay et Beebs comme d'habitude ; l'extension remplit les formulaires depuis votre propre navigateur. Personne d'autre que vous n'est connecté à vos comptes, et vos mots de passe ne sont ni demandés, ni stockés. La contrepartie est physique, et nous préférons l'écrire noir sur blanc : **il faut un ordinateur, avec Chrome ouvert, connecté à vos comptes, allumé pendant la publication**. Ordinateur éteint, les annonces attendent en file et partent à la prochaine ouverture. Vous pilotez tout depuis l'application — y compris depuis votre téléphone — mais c'est votre PC qui exécute.

**Travailler ailleurs, depuis les serveurs de l'outil.** D'autres services opèrent à distance, sans que votre machine soit allumée. Le confort est réel, mais posez alors la seule question qui compte : *avec quelle connexion à vos comptes ?* Si un service publie pendant que votre navigateur est fermé, c'est qu'il détient un accès à vos comptes — identifiants ou session répliquée — sur ses propres machines. Ce n'est pas forcément disqualifiant, mais c'est une information que vous devez avoir avant de confier vos comptes de vendeur, et elle est rarement mise en avant.

Il n'y a pas de solution magique qui cumule « aucun accès à vos comptes » et « fonctionne PC éteint ». Un outil honnête vous dit où il se situe ; méfiez-vous de ceux qui ne répondent pas à la question.

## Avant de choisir un outil de cross-listing : la liste des questions

Quatre questions suffisent à faire le tri, quel que soit l'outil.

1. **Quelles plateformes, réellement ?** Beaucoup d'outils du marché français ne couvrent que Vinted — utiles pour gérer un dressing, mais ce n'est pas du cross-listing. Vérifiez que les sites qui comptent pour *vos* articles sont couverts en publication complète, pas seulement en « suivi ».
2. **Cross-listing, republication, ou les deux — et à quelle cadence ?** Les deux sont légitimes ; ce qui compte, c'est le rythme et la maîtrise. Un outil qui republie sans plafond réglable, sans bouton d'arrêt et à cadence de robot fait porter le risque à votre compte, pas au sien.
3. **Que se passe-t-il à la vente ?** Sans retrait des autres plateformes, le cross-listing crée plus de problèmes qu'il n'en résout. C'est la fonctionnalité à exiger, pas une option de confort.
4. **Où s'exécute la publication, et avec quels accès ?** Dans votre navigateur avec vos sessions, ou sur les serveurs de l'outil avec une connexion à vos comptes ? Les deux existent ; l'important est que l'outil le dise.

## Ce que fait FillSell, en clair

Pour que la comparaison soit possible, voici nos réponses aux quatre questions, sans détour.

- **Plateformes** : Vinted, Leboncoin, eBay et Beebs, en publication complète — formulaire rempli champ par champ, photos comprises. Vous activez de une à quatre plateformes, article par article.
- **Publication** : une seule fois, en un clic, avec des délais variables entre les actions. La republication Vinted existe à côté, à votre main : rythme humain, plafond que vous réglez, coupure à tout moment — manuelle sur tous les plans, automatisable avec le plan Pro.
- **À la vente** : FillSell détecte la vente et vous prévient. Vous confirmez, il retire les annonces des autres plateformes — en un tap, ou site par site si vous préférez choisir.
- **Exécution** : dans votre navigateur, via [l'extension Chrome FillSell](https://chromewebstore.google.com/detail/ooeagobimgoabciggfamljdfpkginhnm), avec vos sessions — jamais vos mots de passe. Il faut un ordinateur allumé avec Chrome ouvert pendant la publication ; PC éteint, vos annonces attendent en file.

Et parce que vendre plus n'a d'intérêt que si l'on gagne de l'argent, chaque article publié rejoint votre stock avec son prix d'achat et son prix de vente — [vos marges se calculent toutes seules](/blog/comment-calculer-profits-vinted).

Envie de voir le parcours complet, de la photo à l'annonce en ligne ? [Créez votre première annonce sur FillSell](https://fillsell.app), ou lisez d'abord [comment se déroule une publication multi-plateformes](/blog/publier-annonce-plusieurs-plateformes).

## FAQ

### Quelle est la différence entre cross-listing et republication automatique ?

Le cross-listing publie un article une seule fois, sur plusieurs plateformes à la fois : il élargit l'audience. La republication redépose une annonce sur un seul site pour la faire remonter dans les résultats : elle relance la visibilité d'un article qui n'est plus vu. Les deux se complètent, et FillSell fait les deux — la republication au rythme d'une vraie personne, avec un plafond que vous réglez et une coupure à tout moment. Ce qui expose un compte, c'est la cadence de robot, pas le geste.

### Vendre le même article sur plusieurs plateformes est-il autorisé ?

Publier un même article sur Vinted, Leboncoin, eBay et Beebs relève de votre liberté de vendeur : chaque annonce est déposée normalement, via le formulaire du site. Ce qui expose un compte, ce sont les cadences de robot — une annonce recyclée toutes les heures, des échanges de favoris artificiels — pas le fait de vendre au même moment sur plusieurs sites.

### Comment éviter de vendre deux fois le même article ?

C'est le vrai risque du cross-listing. Il faut que l'outil détecte la vente sur une plateforme et retire l'annonce des autres. FillSell détecte la vente et vous prévient : vous confirmez, et il retire les annonces des autres plateformes en un tap. Le retrait n'est jamais déclenché sans vous — une disparition d'annonce n'est pas toujours une vente.

### FillSell fonctionne-t-il ordinateur éteint ?

Non, et nous préférons le dire clairement : les publications et retraits passent par l'extension Chrome, donc par votre navigateur, avec vos sessions. Ordinateur éteint, rien ne part — les annonces attendent en file et partent à la prochaine ouverture de Chrome.

### Sur combien de plateformes FillSell publie-t-il ?

Quatre : Vinted, Leboncoin, eBay et Beebs. Vous choisissez lesquelles activer, article par article — de une à quatre.
`,n=`---
title: "Reselling Profit: What You Actually Make Per Sale (Formula + Examples)"
description: "Most resellers overestimate their profit. Platform fees, payment processing, packaging, shipping: the full formula with worked examples, plus the ROI mistake that eats your margin."
date: "2026-06-20"
lang: "en"
og_image: "/og-image-en.png"
---

Reselling looks simple on paper: buy low, sell high. But without tracking every cost, you can easily work long hours and end up with razor-thin margins — or losses you didn't see coming.

Here's the complete method for calculating your real profit on any reselling platform.

## Every cost that eats into your margin

Most resellers only think about the buying price. Here's what actually matters.

### 1. Acquisition cost

Everything you paid to get the item: thrift stores, garage sales, wholesale lots, liquidation pallets, or even other marketplaces. This is your baseline.

### 2. Platform fees

Every platform takes a cut from your sale:

| Platform | Seller fee |
|---|---|
| eBay | ~13.25% of final value |
| Depop | 10% |
| StockX | 8–10% |
| Vinted | **0% (buyer pays)** |
| Facebook Marketplace | 5% (shipped) |

This alone can wipe out a quarter of your revenue before you touch it.

### 3. Payment processing

PayPal, Stripe, or built-in checkout systems typically charge **2.9% + $0.30 per transaction**. On a $40 sale, that's $1.46 off the top.

### 4. Packaging

Poly mailers, boxes, tissue paper, tape, labels — it adds up. Budget **$0.40–$1.50 per item** depending on what you're shipping.

### 5. Shipping (if you offer free shipping)

Free shipping is a conversion driver, but someone pays for it — and that someone is you. Budget the actual carrier rate per item category.

## The profit formula

\`\`\`
Net Profit = Sale Price − Acquisition Cost − Platform Fee − Payment Fee − Packaging − Shipping
\`\`\`

**Worked example — Nike Air Force 1:**

| | |
|---|---|
| Bought at thrift store | $12 |
| Sold on eBay | $65 |
| eBay fee (13.25%) | $8.61 |
| PayPal fee (2.9% + $0.30) | $2.19 |
| Packaging | $1.20 |
| Shipping (absorbed) | $7.00 |
| **Net profit** | **$34.00** |
| **Margin** | **52%** |

You didn't make $53. You made $34. That's still a great flip — but the number matters.

## Return on Investment (ROI)

ROI tells you how efficiently you're deploying capital:

\`\`\`
ROI = (Net Profit ÷ Acquisition Cost) × 100
\`\`\`

For the Air Force 1: \`(34 ÷ 12) × 100 = **283%**\`

ROI is especially useful when comparing opportunities. A $5 profit on a $6 item (83% ROI) is often a better use of capital than a $20 profit on a $100 item (20% ROI).

## Buying in lots

Lot buying changes the math entirely. If you buy a 15-pair shoe lot for $90, your per-unit cost is **$6** — not $90. Apply that to each item individually:

\`\`\`
Unit cost = Total lot cost ÷ Number of items
\`\`\`

Track each item separately from there. Some will sell fast at high margin; some will sit or go below average. Your lot's overall profitability is the sum of all individual sales minus the $90.

## Common mistakes

**Ignoring platform fees.** Forgetting eBay's 13% on a $50 item means you miscalculate profit by $6.50. At 50 sales a month, that's $325 of invisible loss.

**Counting revenue as profit.** $3,000 in monthly sales is not $3,000 in earnings. Your real income is what's left after every cost.

**Skipping packaging math.** At $1 per item, 200 monthly sales = $200 in hidden costs.

**Not tracking slow inventory.** Capital tied up in unsold stock is capital you can't reinvest. An item sitting for 4 months has an opportunity cost.

**Using a single average margin.** Different categories have wildly different cost structures. Track them separately.

## Automate it

Manually running these numbers for 30+ items a week is exhausting — and prone to error. FillSell does all of this automatically: log your purchases by voice, and the app instantly calculates margin, ROI, and profit across your entire inventory in real time.
`,r=`---
title: "Publier ses annonces sur plusieurs plateformes en une seule fois"
description: "Publier la même annonce sur Vinted, Leboncoin, eBay et Beebs sans rien recopier : ce que l'extension FillSell automatise vraiment, et ce qui reste à faire."
date: "2026-07-30"
lang: "fr"
og_image: "/og-image-fillsell.png"
faq: [{"q":"Sur quelles plateformes FillSell publie-t-il ?","a":"Sur Vinted, Leboncoin, eBay et Beebs. Vous choisissez, annonce par annonce, lesquelles activer — de une à quatre."},{"q":"Faut-il laisser son ordinateur allumé ?","a":"Pour que les publications partent, oui : l'extension travaille quand Chrome est ouvert. Si l'ordinateur est éteint, les annonces restent en file d'attente et partent à la prochaine ouverture de Chrome."},{"q":"L'extension connaît-elle mes mots de passe ?","a":"Non. Elle utilise les sessions déjà ouvertes dans votre navigateur : c'est vous qui vous connectez à chaque plateforme, comme d'habitude. FillSell ne demande ni ne stocke aucun identifiant de plateforme."},{"q":"Puis-je relire et modifier l'annonce avant publication ?","a":"Oui. Chaque plateforme a sa propre version de l'annonce (titre, description, prix, champs), que vous pouvez éditer avant de cliquer sur Publier. Rien ne part sans votre clic."},{"q":"Que se passe-t-il si je ne suis pas connecté à une plateforme ?","a":"L'annonce attend. L'application vous signale la connexion manquante, et la publication repart d'elle-même une fois que vous êtes reconnecté sur le site concerné."},{"q":"Comment retirer une annonce publiée ?","a":"Depuis l'application : un clic sur le logo d'une plateforme retire l'annonce de ce site uniquement, et un article marqué vendu peut être retiré des autres plateformes. C'est l'extension qui exécute la suppression sur les sites."}]
---

Vous vendez un blouson. Pour lui donner toutes ses chances, il faudrait le publier sur Vinted, sur Leboncoin, peut-être aussi sur eBay et sur Beebs. Quatre sites, quatre formulaires, quatre fois les mêmes photos à téléverser, le même titre à retaper, la même description à recoller, les mêmes menus de catégorie, d'état et de couleur à dérouler. C'est exactement le problème que résout FillSell : publier ses annonces sur plusieurs plateformes en une seule fois, en ne rédigeant l'annonce qu'une seule fois.

Cet article décrit précisément ce que fait l'extension Chrome de FillSell, ce qu'elle ne fait pas, et ce qui reste entre vos mains.

![Une annonce rédigée une fois dans FillSell, publiée sur quatre plateformes de seconde main](/og-image-fillsell.png)

## Pourquoi vendre sur plusieurs plateformes en même temps ?

Parce que les acheteurs ne sont pas au même endroit. Un jean se vend très bien sur Vinted, un meuble part sur Leboncoin, une pièce recherchée trouve preneur sur eBay, un vêtement d'enfant sur Beebs. Publier au même moment sur plusieurs sites multiplie l'exposition d'un article sans multiplier le travail — à condition, justement, de ne pas devoir tout recopier à la main.

C'est la partie pénible de la revente : la ressaisie. Chaque plateforme a son formulaire, ses champs obligatoires, ses catégories, ses libellés d'état qui ne correspondent pas d'un site à l'autre (« Très bon état » ici, « État neuf » là). Faire ce travail pour chaque article, c'est ce qui pousse la plupart des vendeurs à se limiter à un seul site. Cette pratique porte d'ailleurs un nom — le cross-listing — et nous lui avons consacré [un guide pour bien choisir son outil](/blog/cross-listing-vinted-leboncoin), et pour comprendre ce qui le distingue de la republication.

## Comment publier ses annonces sur plusieurs plateformes sans les recopier ?

Avec FillSell, vous ne remplissez qu'un seul parcours, dans l'application : les photos, le prix, et les informations de l'article. L'application prépare ensuite une version de l'annonce **par plateforme** — chacune avec le ton et les champs attendus par le site en question — que vous relisez et modifiez librement. Vous cochez les plateformes voulues, vous cliquez sur Publier : la suite est prise en charge par l'extension Chrome.

Concrètement, le parcours ressemble à ceci :

1. **Vous ajoutez les photos** de l'article (elles servent à toutes les plateformes).
2. **L'application rédige un brouillon d'annonce par plateforme** : titre, description, et les champs propres à chaque site — catégorie, état, taille, couleur, matière, marque…
3. **Vous relisez, corrigez, fixez le prix.** Chaque version reste éditable individuellement ; rien n'est publié sans votre validation.
4. **Vous choisissez les plateformes** (de une à quatre) et cliquez sur Publier.
5. **L'extension Chrome publie pour vous**, plateforme par plateforme, et l'application affiche l'avancement puis le lien de chaque annonce en ligne.

## Que fait l'extension Chrome à votre place, concrètement ?

Elle fait ce que vous auriez fait au clavier : elle ouvre le vrai formulaire de dépôt de chaque site et le remplit champ par champ. Il n'y a pas de passe-droit ni de connexion cachée aux plateformes — ce sont les formulaires publics des sites, remplis à votre place, depuis votre navigateur, avec vos comptes.

Dans le détail, pour chaque plateforme sélectionnée, l'extension :

- ouvre la page de dépôt du site dans une fenêtre de travail dédiée, qui reste en arrière-plan — elle ne vole jamais votre écran ni votre souris ;
- téléverse vos photos ;
- saisit le titre et la description, à un rythme de frappe naturel ;
- sélectionne la catégorie correspondant à votre article dans l'arborescence propre au site ;
- remplit les champs spécifiques (état, taille, couleur, matière, marque, et les champs obligatoires que certains sites ajoutent selon la catégorie) ;
- pose le prix ;
- valide le dépôt, **et vérifie que le site a réellement confirmé la publication** avant de marquer l'annonce comme publiée. Une annonce n'est jamais déclarée « en ligne » sur la seule foi d'un clic parti.

Une fois l'annonce en ligne, l'application récupère son adresse : depuis votre stock, vous voyez sur quelles plateformes chaque article est publié, avec un lien direct vers chaque annonce.

### Des annonces adaptées à chaque site, pas un copier-coller

Publier le même texte partout est rarement une bonne idée : les codes de Vinted ne sont pas ceux de Leboncoin, et les libellés d'état ou de catégorie diffèrent d'un site à l'autre. FillSell génère une version par plateforme — le fond reste identique et fidèle à votre article, la forme s'adapte. Et la règle d'écriture est stricte : l'annonce ne contient que ce qui est établi par vos photos et vos informations. Pas de matière devinée, pas d'usage inventé, pas de superlatif.

## Qu'est-ce qui reste à votre charge ?

Trois choses, et il est honnête de les nommer.

**Être connecté à vos comptes.** L'extension publie avec vos sessions existantes : il faut être connecté à Vinted, Leboncoin, eBay ou Beebs dans Chrome, comme vous l'êtes déjà en temps normal. Si une session manque, l'annonce attend et l'application vous l'indique — elle repart une fois la connexion rétablie. FillSell ne vous demande jamais vos mots de passe de plateforme.

**Laisser Chrome ouvert.** Les publications partent quand votre ordinateur est allumé et Chrome ouvert avec l'extension. Ordinateur éteint ? Les annonces restent en file d'attente et partent automatiquement à la prochaine ouverture.

**Relire vos annonces.** L'application prépare, vous décidez. Le prix, le contenu final et le choix des plateformes restent votre décision — c'est votre clic sur Publier qui déclenche tout.

## Et si une plateforme demande une vérification ?

Ça arrive, et FillSell ne le cache pas : la publication n'est pas toujours 100 % automatique de bout en bout.

Certains cas demandent une intervention de votre part, et l'application vous les signale clairement au lieu d'échouer en silence : un champ obligatoire que le site exige et qu'aucune donnée ne permet de remplir (l'application vous propose alors de le compléter en deux clics), une adresse de remise manquante pour Leboncoin, une session expirée à reconnecter, ou une vérification anti-robot affichée par le site — dans ce cas, c'est à vous de la résoudre dans votre navigateur, puis la publication reprend. Enfin, certaines plateformes modèrent les annonces avant leur mise en ligne : l'annonce est bien déposée, le lien public arrive un peu plus tard.

Dans tous ces cas, rien n'est perdu : l'annonce reste en attente et repart dès que le point est réglé.

## La publication est-elle instantanée ?

Non, et c'est volontaire. Quand vous cliquez sur Publier, vos annonces partent en file d'attente ; l'extension les traite dans les minutes qui suivent, l'une après l'autre. Le remplissage lui-même prend le temps d'une saisie soignée — l'extension écrit à un rythme naturel plutôt que d'injecter tout d'un coup. Comptez donc quelques minutes entre votre clic et la mise en ligne effective, un peu plus quand plusieurs annonces s'enchaînent. Pendant ce temps, vous faites autre chose : tout se passe en arrière-plan.

## Et après la vente ?

La gestion ne s'arrête pas à la publication. Chaque article publié rejoint votre stock dans l'application, avec son prix d'achat et son prix de vente — vos marges se calculent toutes seules. Quand un article se vend, le retrait des annonces passe par le même mécanisme que la publication : depuis l'application, un clic sur le logo d'une plateforme retire l'annonce de ce site précis, et un article marqué vendu peut être retiré des autres plateformes — c'est l'extension qui exécute la suppression sur les sites, de la même façon invisible. Fini l'article vendu sur un site qui continue de recevoir des messages sur les trois autres.

Envie d'essayer ? [Créez votre première annonce sur FillSell](https://fillsell.app) — et retrouvez le détail de l'installation sur [la page extension](/extension).

## FAQ

### Sur quelles plateformes FillSell publie-t-il ?

Sur Vinted, Leboncoin, eBay et Beebs. Vous choisissez, annonce par annonce, lesquelles activer — de une à quatre.

### Faut-il laisser son ordinateur allumé ?

Pour que les publications partent, oui : l'extension travaille quand Chrome est ouvert. Si l'ordinateur est éteint, les annonces restent en file d'attente et partent à la prochaine ouverture de Chrome.

### L'extension connaît-elle mes mots de passe ?

Non. Elle utilise les sessions déjà ouvertes dans votre navigateur : c'est vous qui vous connectez à chaque plateforme, comme d'habitude. FillSell ne demande ni ne stocke aucun identifiant de plateforme.

### Puis-je relire et modifier l'annonce avant publication ?

Oui. Chaque plateforme a sa propre version de l'annonce (titre, description, prix, champs), que vous pouvez éditer avant de cliquer sur Publier. Rien ne part sans votre clic.

### Que se passe-t-il si je ne suis pas connecté à une plateforme ?

L'annonce attend. L'application vous signale la connexion manquante, et la publication repart d'elle-même une fois que vous êtes reconnecté sur le site concerné.

### Comment retirer une annonce publiée ?

Depuis l'application : un clic sur le logo d'une plateforme retire l'annonce de ce site uniquement, et un article marqué vendu peut être retiré des autres plateformes. C'est l'extension qui exécute la suppression sur les sites.
`,i=Object.assign({"./comment-calculer-profits-vinted.md":e,"./cross-listing-vinted-leboncoin.md":t,"./how-to-calculate-reselling-profits.md":n,"./publier-annonce-plusieurs-plateformes.md":r});function a(e){let t=e.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/);if(!t)return{data:{},content:e};let n={};return t[1].split(`
`).forEach(e=>{let t=e.indexOf(`:`);if(t===-1)return;let r=e.slice(0,t).trim(),i=e.slice(t+1).trim().replace(/^["']|["']$/g,``);r&&(n[r]=i)}),{data:n,content:t[2]}}var o=Object.entries(i).map(([e,t])=>{let n=e.replace(`./`,``).replace(`.md`,``),{data:r,content:i}=a(t);return{slug:n,...r,content:i}}).sort((e,t)=>new Date(t.date)-new Date(e.date));function s(e){return o.find(t=>t.slug===e)??null}export{o as n,s as t};